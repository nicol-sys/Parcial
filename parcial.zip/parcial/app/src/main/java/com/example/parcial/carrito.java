package com.example.parcial;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

public class carrito extends AppCompatActivity {
    private TextView resultado1;
    private TextView resultado2;
    Button Comprar;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_carrito);
        Comprar = findViewById(R.id.Comprar);
        Comprar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                Intent intent = new Intent(carrito.this, info.class);
                startActivity(intent);
            }
        });
    }

    public void Ver (View view) {
        resultado1.setText("Flor azul");
        resultado2.setText("Flor roja");
    }
}
